// ============================================================
//  MYTHBOUND — Shared Data Layer
//  Import this in every page: <script src="mythbound_shared.js"></script>
//  In production: replace MB.PLAYER reads/writes with Supabase calls.
// ============================================================

const MB = {};

// ── PLAYER STATE ─────────────────────────────────────────────
// Single source of truth for the logged-in player.
// Pages read MB.PLAYER; writes call MB.setPlayer(patch) so
// BroadcastChannel can sync across tabs.
MB.PLAYER = {
  id:         'raven',
  name:       'RAVEN',
  em:         '🐦‍⬛',
  title:      'Phoenix Mythbound',
  level:      12,
  role:       'Striker',
  myth:       'Phoenix',        // bound myth creature
  coins:      4820,
  // Professions: level + xp toward next level
  professions: {
    fishing:      { level:4,  xp:420,  xpMax:1000 },
    mining:       { level:7,  xp:210,  xpMax:1000 },
    herbalism:    { level:1,  xp:0,    xpMax:100  },
    hunting:      { level:1,  xp:0,    xpMax:100  },
  },
  craft: 'blacksmithing',       // one craft per player; null = none chosen
  craftLevel: 3,
  craftXp: 80, craftXpMax: 300,
  energy:     800,
  energyMax:  1000,
  // Combat stats (used by battle page)
  hp: 110, mhp: 110,
  mp: 80,  mmp: 80,
  atk: 24, def: 14, spd: 14,
  lb: 0,
  row: 'front',
};

MB.setPlayer = function(patch) {
  Object.assign(MB.PLAYER, patch);
  if (MB._BC) MB._BC.postMessage({ type:'player_update', data: MB.PLAYER });
};

// ── BROADCAST CHANNEL ────────────────────────────────────────
// Same-origin cross-tab sync. In production → Supabase Realtime.
MB._BC = (() => {
  try { return new BroadcastChannel('mythbound_main'); } catch(e) { return null; }
})();
MB._bcListeners = [];
MB.onBC = function(fn) { MB._bcListeners.push(fn); };
if (MB._BC) {
  MB._BC.onmessage = e => MB._bcListeners.forEach(fn => fn(e.data));
}

// ── NAVIGATION ───────────────────────────────────────────────
MB.PAGES = {
  hub:        'mythbound_hub.html',
  games:      'mythbound_games.html',
  fishing:    'mythbound_fishing_lobby.html',
  mining:     'mythbound_mining.html',
  battle:     'mythbound_battle.html',
  inventory:  'mythbound_inventory.html',
  admin:      'mythbound_admin_minigames.html',
};
MB.nav = function(page) {
  const dest = MB.PAGES[page];
  if (dest) window.location.href = dest;
  else console.warn('MB.nav: unknown page "' + page + '"');
};

// ── RARITY ───────────────────────────────────────────────────
// Static hex for all rarities. Ultimate uses CSS animation —
// anywhere you'd set a color, use MB.ultimateStyle() instead.
MB.RC = {
  common:    '#999',
  uncommon:  '#6bff9b',
  rare:      '#6bb5ff',
  epic:      '#c455e8',
  legendary: '#ffdd6b',
  ultimate:  null,   // never a static hex — always animated CSS
};
MB.RORD = { common:0, uncommon:1, rare:2, epic:3, legendary:4, ultimate:5 };

// Returns inline style string for a rarity color (non-ultimate).
// For ultimate, use MB.ultimateClass() on the element instead.
MB.rarityColor = function(rar) {
  return MB.RC[rar] || '#fff';
};

// CSS to inject once per page — defines the rainbow animation
// and all .mb-ult-* helper classes.
MB.ULTIMATE_CSS = `
@keyframes mb-rainbow {
  0%   { filter: hue-rotate(0deg); }
  100% { filter: hue-rotate(360deg); }
}
@keyframes mb-rainbow-bg {
  0%   { background-position: 0% 50%; }
  100% { background-position: 200% 50%; }
}
/* Text that cycles through rainbow */
.mb-ult-text {
  background: linear-gradient(90deg,
    #ff0000,#ff8800,#ffff00,#00ff88,#00ccff,#8844ff,#ff0088,#ff0000);
  background-size: 200% auto;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  animation: mb-rainbow-bg 2.4s linear infinite;
}
/* Border wrapper: add 2px rainbow border around any block element */
.mb-ult-border {
  background: linear-gradient(90deg,
    #ff0000,#ff8800,#ffff00,#00ff88,#00ccff,#8844ff,#ff0088,#ff0000);
  background-size: 200% auto;
  animation: mb-rainbow-bg 2.4s linear infinite;
  padding: 2px;
  display: inline-block;
}
.mb-ult-border > * { background: #000; display: block; }
/* Badge: black text on sliding rainbow block */
.mb-ult-badge {
  background: linear-gradient(90deg,
    #ff0000,#ff8800,#ffff00,#00ff88,#00ccff,#8844ff,#ff0088,#ff0000);
  background-size: 200% auto;
  animation: mb-rainbow-bg 2.4s linear infinite;
  color: #000 !important;
  font-weight: bold;
  padding: 2px 6px;
}
/* Dot indicator */
.mb-ult-dot {
  background: linear-gradient(90deg,
    #ff0000,#ff8800,#ffff00,#00ff88,#00ccff,#8844ff,#ff0088,#ff0000);
  background-size: 200% auto;
  animation: mb-rainbow-bg 2.4s linear infinite;
}
/* Item link in chat */
.item-link.ultimate {
  background: linear-gradient(90deg,
    #ff0000,#ff8800,#ffff00,#00ff88,#00ccff,#8844ff,#ff0088,#ff0000);
  background-size: 200% auto;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  animation: mb-rainbow-bg 2.4s linear infinite;
  border-color: transparent;
  text-shadow: none;
}
`;

// Call once at page load to inject the CSS
MB.injectUltimateCSS = function() {
  if (document.getElementById('mb-ultimate-css')) return;
  const s = document.createElement('style');
  s.id = 'mb-ultimate-css';
  s.textContent = MB.ULTIMATE_CSS;
  document.head.appendChild(s);
};

// ── ITEM DATABASE ─────────────────────────────────────────────
// Master item list. Minigame drops reference item ids from here.
MB.ITEMS = {
  // EQUIPMENT
  iron_crown:      { name:'Iron Crown',      emoji:'⛑️',  rarity:'rare',     type:'equipment', slot:'helm',    stats:{def:8,stm:20},  element:'physical', sell:180, desc:'A battered crown taken from a dungeon guardian.' },
  ashen_vest:      { name:'Ashen Vest',      emoji:'🦺',  rarity:'uncommon', type:'equipment', slot:'chest',   stats:{def:5,stm:15},  element:'physical', sell:90,  desc:'Leather hardened in volcanic ash.' },
  void_blade:      { name:'Void Blade',      emoji:'⚔️',  rarity:'epic',     type:'equipment', slot:'main',    stats:{atk:18,agi:2},  element:'void',     sell:400, desc:'Forged from compressed darkness. Whispers when drawn.' },
  iron_shield:     { name:'Iron Shield',     emoji:'🛡️',  rarity:'common',   type:'equipment', slot:'off',     stats:{def:6,stm:10},  element:'physical', sell:80,  desc:'Heavy and dependable.' },
  silver_ring:     { name:'Silver Ring',     emoji:'💍',  rarity:'uncommon', type:'equipment', slot:'ring',    stats:{wil:12,agi:1},  element:'arcana',   sell:110, desc:'Faintly magical. Hums when held.' },
  ember_boots:     { name:'Ember Boots',     emoji:'🥾',  rarity:'rare',     type:'equipment', slot:'boots',   stats:{agi:4,atk:3},   element:'fire',     sell:160, desc:'Warm to the touch. Forged in volcanic stone.' },
  sage_legs:       { name:'Sage Legguards',  emoji:'👖',  rarity:'uncommon', type:'equipment', slot:'legs',    stats:{wil:8,stm:12},  element:'nature',   sell:95,  desc:'Woven from enchanted bark-fiber.' },
  crystal_trinket: { name:'Crystal Shard',   emoji:'💠',  rarity:'epic',     type:'equipment', slot:'trinket', stats:{arc:14,wil:6},  element:'arcana',   sell:350, desc:'A fragment of a shattered mana crystal.' },
  // CONSUMABLES
  potion:          { name:'Potion',          emoji:'🧪',  rarity:'common',   type:'consumable', effect:'Heal 40 Stamina',    sell:20,  desc:'A basic healing potion.' },
  ether:           { name:'Ether',           emoji:'💧',  rarity:'common',   type:'consumable', effect:'Restore 30 MP',      sell:20,  desc:'Restores magical energy.' },
  elixir:          { name:'Elixir',          emoji:'⚗️',  rarity:'rare',     type:'consumable', effect:'Full Stamina + MP',  sell:200, desc:'Save it for when it counts.' },
  antidote:        { name:'Antidote',        emoji:'💊',  rarity:'common',   type:'consumable', effect:'Cure Venom',         sell:15,  desc:'Purges toxins.' },
  bomb:            { name:'Bomb',            emoji:'💣',  rarity:'uncommon', type:'consumable', effect:'60 Physical dmg',    sell:60,  desc:'Light fuse. Step back.' },
  // MATERIALS — Mining
  stone:           { name:'Stone',           emoji:'🪨',  rarity:'common',   type:'material', source:'mining', sell:2,   desc:'Basic stone.' },
  copper_ore:      { name:'Copper Ore',      emoji:'🟤',  rarity:'common',   type:'material', source:'mining', sell:10,  desc:'Smelts into copper ingots.' },
  tin_ore:         { name:'Tin Ore',         emoji:'⬜',  rarity:'uncommon', type:'material', source:'mining', sell:18,  desc:'Used in bronze alloys.' },
  iron_ore:        { name:'Iron Ore',        emoji:'🔩',  rarity:'common',   type:'material', source:'mining', sell:15,  desc:'Common and useful.' },
  coal:            { name:'Coal',            emoji:'⬛',  rarity:'uncommon', type:'material', source:'mining', sell:22,  desc:'Fuel and smithing input.' },
  silver_ore:      { name:'Silver Ore',      emoji:'🔘',  rarity:'common',   type:'material', source:'mining', sell:28,  desc:'Bright and conductive.' },
  quartz:          { name:'Quartz',          emoji:'💎',  rarity:'uncommon', type:'material', source:'mining', sell:35,  desc:'Alchemical reagent.' },
  mithril_ore:     { name:'Mithril Ore',     emoji:'🔵',  rarity:'rare',     type:'material', source:'mining', sell:300, desc:'Found only in deep veins.' },
  geode:           { name:'Geode',           emoji:'🔮',  rarity:'legendary',type:'material', source:'mining', sell:800, desc:'Crystalline wonder.' },
  // MATERIALS — Fishing
  root_fiber:      { name:'Root Fiber',      emoji:'🪢',  rarity:'common',   type:'material', source:'fishing', sell:8,   desc:'Used in leatherwork.' },
  ancient_sap:     { name:'Ancient Sap',     emoji:'🫙',  rarity:'rare',     type:'material', source:'fishing', sell:120, desc:'Alchemical reagent.' },
  shadow_gem:      { name:'Shadow Gem',      emoji:'💎',  rarity:'epic',     type:'material', source:'fishing', sell:500, desc:'Sought by enchanters.' },
  // KEY ITEMS
  deeproot_key:    { name:'Deeproot Key',    emoji:'🗝️',  rarity:'uncommon', type:'key',  sell:0,   desc:'Unlocks the Sealed Chamber.' },
  myth_heart:      { name:'Myth Heart',      emoji:'💜',  rarity:'ultimate', type:'key',  sell:0,   desc:'Used for myth binding. Soulbound.', soulbound:true },
  phoenix_binding: { name:'Phoenix Binding', emoji:'🔥',  rarity:'ultimate', type:'key',  sell:0,   desc:'Your mythbound connection to the Phoenix. Cannot be removed or traded.', soulbound:true, mythBound:true },
};

// ── PROFESSIONS ───────────────────────────────────────────────
// Gathering professions have level-gated material tiers.
// Craft professions: one per player, full progress lost on switch.
MB.GATHERING_PROFS = ['fishing','mining','herbalism','hunting'];
MB.CRAFT_PROFS = ['blacksmithing','cooking','alchemy','leatherworking'];

MB.PROF_XP_TABLE = [
  { upTo:20, xpPerLevel:100  },
  { upTo:50, xpPerLevel:300  },
  { upTo:80, xpPerLevel:700  },
  { upTo:99, xpPerLevel:1500 },
  { upTo:100,xpPerLevel:3000 },
];
MB.xpForLevel = function(lvl) {
  const row = MB.PROF_XP_TABLE.find(r => lvl <= r.upTo);
  return row ? row.xpPerLevel : 3000;
};

// Economy: shop sell rates (player selling TO shop = lower than AH)
MB.SHOP_RATE = 0.4; // player gets 40% of sell value at NPC shop

// ── FISHING CONFIG ────────────────────────────────────────────
// FC is the live-tunable fishing config (also edited by admin panel).
// Admin panel writes to this via BroadcastChannel.
MB.FC = {
  bar:{ base:52, pxPerLevel:3, lureBonus:14 },
  catchRate:{ max:0.55, min:0.16, slope:0.0038 },
  patienceDrain:{ min:0.14, max:0.83, slope:0.0073, regenOnFish:0.012, catchBleedOff:0.06 },
  patienceComp:{ highThresh:0.20, lowThresh:0.12, highMult:0.80, midMult:0.90 },
  fish:{
    speedMult:0.055, velCapMult:2.2, wallBounce:-0.6,
    dartAmpFraction:0.80, dartAmpCapMult:1.4,
    behaviors:{
      smooth:  { damp:0.97, forceMult:0.65 },
      sinker:  { damp:0.98, gravity:0.22, gravitySpread:0.10, burstChance:0.022, burstMult:1.2, burstSpread:0.9 },
      floater: { damp:0.98, gravity:0.22, gravitySpread:0.10, burstChance:0.022, burstMult:1.2, burstSpread:0.9 },
      mixed:   { damp:0.95, forceMult:0.90 },
      dart:    { damp:0.82, forceMult:0.08 },
    },
    dartIntervals:{ dart:{min:12,spread:16}, mixed:{min:28,spread:28}, other:{min:50,spread:40} },
  },
  playerBar:{ accel:0.132, velCap:20, wallBounce:0.667 },
  timing:{ biteWaitMinMs:2000, biteWaitRandMs:4000, biteWindowMs:3000 },
  erratic:{ perLevelOver:0.20, cap:2.0, underBonus:0.82 },
  energyCostPerCatch: 40,
  rods:[
    { id:'basic', name:'WOODEN ROD', emoji:'🪡', tier:1, min:1, max:4, cost:0,    reqLvl:0, barBonus:0,  driftDamp:0,    desc:'Reliable. Gets the job done.',        stats:['BASE BAR +0px','STD REEL','LV1-4'] },
    { id:'fiber', name:'FIBER ROD',  emoji:'🎣', tier:2, min:5, max:8, cost:1200, reqLvl:4, barBonus:8,  driftDamp:0.97, desc:'Wider catch window. Less overshoot.', stats:['BASE BAR +8px','LESS DRIFT','LV5-8'] },
  ],
  bait:[
    { id:'none',  name:'BARE HOOK', emoji:'🪝', cost:0,  qty:999, consumable:false, poolKey:'none',  barBonus:0,  desc:'Standard rates.' },
    { id:'worm',  name:'WORM',      emoji:'🪱', cost:5,  qty:24,  consumable:true,  poolKey:'worm',  barBonus:0,  desc:'+Rare fish odds.' },
    { id:'lure',  name:'LURE',      emoji:'✨', cost:25, qty:8,   consumable:true,  poolKey:'lure',  barBonus:14, desc:'Big fish only. +14px bar.' },
    { id:'bread', name:'BREAD',     emoji:'🍞', cost:3,  qty:15,  consumable:true,  poolKey:'bread', barBonus:0,  desc:'Fast XP, common fish.' },
  ],
  tables:{
    none:[
      {id:'boot',     name:'Old Boot',        em:'👟',rar:'common',   diff:15,beh:'smooth', dartCh:0,    xp:3,  sell:0,  desc:"Someone lost a boot.",w:8},
      {id:'perch',    name:'Common Perch',    em:'🐟',rar:'common',   diff:25,beh:'smooth', dartCh:0.04, xp:12, sell:12, desc:"A plain river perch.",w:40},
      {id:'roach',    name:'River Roach',     em:'🐠',rar:'common',   diff:32,beh:'mixed',  dartCh:0.06, xp:14, sell:15, desc:"Slippery little thing.",w:32},
      {id:'carp',     name:'Muddy Carp',      em:'🐡',rar:'common',   diff:38,beh:'sinker', dartCh:0.06, xp:18, sell:22, desc:"Bottom feeder.",w:22},
      {id:'duck',     name:'Angry Duck',      em:'🦆',rar:'uncommon', diff:28,beh:'floater',dartCh:0.08, xp:30, sell:0,  desc:"It bit your line.",w:5},
      {id:'eel',      name:'River Eel',       em:'🫎',rar:'uncommon', diff:52,beh:'sinker', dartCh:0.10, xp:35, sell:60, desc:"Long and pale.",w:14},
      {id:'trout',    name:'Speckled Trout',  em:'🐟',rar:'uncommon', diff:58,beh:'mixed',  dartCh:0.12, xp:40, sell:80, desc:"Good eating.",w:12},
      {id:'bottle',   name:'Sealed Bottle',   em:'🍶',rar:'rare',     diff:42,beh:'smooth', dartCh:0.05, xp:50, sell:140,desc:"Something inside.",w:5},
      {id:'pike',     name:'Ghost Pike',      em:'🐊',rar:'rare',     diff:78,beh:'dart',   dartCh:0.22, xp:65, sell:200,desc:"Massive. Translucent.",w:4},
      {id:'afanc',    name:'Afanc',           em:'🦎',rar:'rare',     diff:62,beh:'sinker', dartCh:0.12, xp:55, sell:90, desc:"Welsh lake beast.",w:6,minLvl:5},
      {id:'ahuizotl', name:'Ahuizotl',        em:'🦦',rar:'rare',     diff:68,beh:'dart',   dartCh:0.18, xp:70, sell:160,desc:"Aztec river spirit.",w:4,minLvl:5},
      {id:'kelpie',   name:'Kelpie',          em:'🐎',rar:'rare',     diff:72,beh:'mixed',  dartCh:0.14, xp:65, sell:150,desc:"Scottish water horse.",w:4,minLvl:5},
      {id:'aspido',   name:'Aspidochelone',   em:'🐢',rar:'rare',     diff:74,beh:'smooth', dartCh:0.10, xp:80, sell:250,desc:"Medieval island-turtle.",w:3,minLvl:9},
      {id:'tiddalik', name:'Tiddalik',        em:'🐸',rar:'rare',     diff:78,beh:'floater',dartCh:0.16, xp:85, sell:280,desc:"Frog that swallowed all water.",w:3,minLvl:9},
      {id:'koi_ryu',  name:'Koi-Ryū',         em:'🐉',rar:'epic',     diff:86,beh:'mixed',  dartCh:0.22, xp:160,sell:620,desc:"Koi mid-ascension.",w:2,minLvl:9},
      {id:'mythcarp', name:'Mythbound Carp',  em:'🐲',rar:'epic',     diff:95,beh:'dart',   dartCh:0.32, xp:200,sell:800,desc:"Mythic energy.",w:1},
      {id:'leviathan',name:'Leviathan Spawn', em:'🐍',rar:'epic',     diff:92,beh:'dart',   dartCh:0.28, xp:180,sell:700,desc:"Coil of the Primordial Sea Beast.",w:2,minLvl:9},
      {id:'qallu',    name:'Qallupilluit',    em:'🫧',rar:'epic',     diff:95,beh:'dart',   dartCh:0.33, xp:220,sell:900,desc:"Inuit ice spirits.",w:1,minLvl:9},
    ],
    worm:[
      {id:'perch',    name:'Common Perch',    em:'🐟',rar:'common',   diff:25,beh:'smooth', dartCh:0.04, xp:12, sell:12, w:26},
      {id:'roach',    name:'River Roach',     em:'🐠',rar:'common',   diff:32,beh:'mixed',  dartCh:0.06, xp:14, sell:15, w:20},
      {id:'carp',     name:'Muddy Carp',      em:'🐡',rar:'common',   diff:38,beh:'sinker', dartCh:0.06, xp:18, sell:22, w:16},
      {id:'eel',      name:'River Eel',       em:'🫎',rar:'uncommon', diff:52,beh:'sinker', dartCh:0.10, xp:35, sell:60, w:20},
      {id:'trout',    name:'Speckled Trout',  em:'🐟',rar:'uncommon', diff:58,beh:'mixed',  dartCh:0.12, xp:40, sell:80, w:18},
      {id:'bottle',   name:'Sealed Bottle',   em:'🍶',rar:'rare',     diff:42,beh:'smooth', dartCh:0.05, xp:50, sell:140,w:7},
      {id:'pike',     name:'Ghost Pike',      em:'🐊',rar:'rare',     diff:78,beh:'dart',   dartCh:0.22, xp:65, sell:200,w:6},
      {id:'kelpie',   name:'Kelpie',          em:'🐎',rar:'rare',     diff:72,beh:'mixed',  dartCh:0.14, xp:65, sell:150,w:5,minLvl:5},
      {id:'koi_ryu',  name:'Koi-Ryū',         em:'🐉',rar:'epic',     diff:86,beh:'mixed',  dartCh:0.22, xp:160,sell:620,w:2,minLvl:9},
      {id:'leviathan',name:'Leviathan Spawn', em:'🐍',rar:'epic',     diff:92,beh:'dart',   dartCh:0.28, xp:180,sell:700,w:2,minLvl:9},
      {id:'mythcarp', name:'Mythbound Carp',  em:'🐲',rar:'epic',     diff:95,beh:'dart',   dartCh:0.32, xp:200,sell:800,w:2},
    ],
    lure:[
      {id:'trout',    name:'Speckled Trout',  em:'🐟',rar:'uncommon', diff:58,beh:'mixed',  dartCh:0.12, xp:40, sell:80, w:26},
      {id:'pike',     name:'Ghost Pike',      em:'🐊',rar:'rare',     diff:78,beh:'dart',   dartCh:0.22, xp:65, sell:200,w:22},
      {id:'eel',      name:'River Eel',       em:'🫎',rar:'uncommon', diff:52,beh:'sinker', dartCh:0.10, xp:35, sell:60, w:20},
      {id:'bottle',   name:'Sealed Bottle',   em:'🍶',rar:'rare',     diff:42,beh:'smooth', dartCh:0.05, xp:50, sell:140,w:10},
      {id:'kelpie',   name:'Kelpie',          em:'🐎',rar:'rare',     diff:72,beh:'mixed',  dartCh:0.14, xp:65, sell:150,w:8,minLvl:5},
      {id:'koi_ryu',  name:'Koi-Ryū',         em:'🐉',rar:'epic',     diff:86,beh:'mixed',  dartCh:0.22, xp:160,sell:620,w:5,minLvl:9},
      {id:'leviathan',name:'Leviathan Spawn', em:'🐍',rar:'epic',     diff:92,beh:'dart',   dartCh:0.28, xp:180,sell:700,w:4,minLvl:9},
      {id:'mythcarp', name:'Mythbound Carp',  em:'🐲',rar:'epic',     diff:95,beh:'dart',   dartCh:0.32, xp:200,sell:800,w:5},
      {id:'qallu',    name:'Qallupilluit',    em:'🫧',rar:'epic',     diff:95,beh:'dart',   dartCh:0.33, xp:220,sell:900,w:2,minLvl:9},
    ],
    bread:[
      {id:'perch',    name:'Common Perch',    em:'🐟',rar:'common',   diff:25,beh:'smooth', dartCh:0.04, xp:12, sell:12, w:42},
      {id:'carp',     name:'Muddy Carp',      em:'🐡',rar:'common',   diff:38,beh:'sinker', dartCh:0.06, xp:18, sell:22, w:36},
      {id:'roach',    name:'River Roach',     em:'🐠',rar:'common',   diff:32,beh:'mixed',  dartCh:0.06, xp:14, sell:15, w:22},
      {id:'boot',     name:'Old Boot',        em:'👟',rar:'common',   diff:15,beh:'smooth', dartCh:0,    xp:3,  sell:0,  w:14},
      {id:'duck',     name:'Angry Duck',      em:'🦆',rar:'uncommon', diff:28,beh:'floater',dartCh:0.08, xp:30, sell:0,  w:6},
      {id:'bottle',   name:'Sealed Bottle',   em:'🍶',rar:'rare',     diff:42,beh:'smooth', dartCh:0.05, xp:50, sell:140,w:4},
    ],
  },
};

// Admin panel can hot-patch FC via BroadcastChannel
MB.onBC(function(msg) {
  if (msg.type === 'fc_update') Object.assign(MB.FC, msg.data);
});

// ── MINING CONFIG ─────────────────────────────────────────────
MB.PICKAXES = {
  copper:  { name:'COPPER',  tier:1, damage:8,  energyCost:10 },
  iron:    { name:'IRON',    tier:2, damage:14, energyCost:18 },
  silver:  { name:'SILVER',  tier:3, damage:22, energyCost:30 },
  mithril: { name:'MITHRIL', tier:4, damage:40, energyCost:60 },
};
MB.ROCKS = {
  copper_rock:  { name:'COPPER ROCK',  tier:1, hp:40,  minLevel:1,  xp:12,  drops:[{item:'stone',      rarity:'common',   pixel:'#888',   weight:60},{item:'copper_ore', rarity:'common',   pixel:'#e8631a',weight:35},{item:'tin_ore',    rarity:'uncommon', pixel:'#c0c0c0',weight:4.9},{item:'geode',      rarity:'legendary',pixel:'#c455e8',weight:0.1}]},
  iron_rock:    { name:'IRON ROCK',    tier:2, hp:90,  minLevel:10, xp:30,  drops:[{item:'stone',      rarity:'common',   pixel:'#888',   weight:50},{item:'iron_ore',   rarity:'common',   pixel:'#a08070',weight:40},{item:'coal',       rarity:'uncommon', pixel:'#222',   weight:9.5},{item:'iron_ore',   rarity:'legendary',pixel:'#ddd',   weight:0.5}]},
  silver_rock:  { name:'SILVER ROCK',  tier:3, hp:150, minLevel:25, xp:55,  drops:[{item:'stone',      rarity:'common',   pixel:'#888',   weight:45},{item:'silver_ore', rarity:'common',   pixel:'#d0d0e0',weight:42},{item:'quartz',     rarity:'uncommon', pixel:'#eee',   weight:12.5},{item:'silver_ore', rarity:'legendary',pixel:'#fff',   weight:0.5}]},
  mithril_rock: { name:'MITHRIL ROCK', tier:4, hp:200, minLevel:50, xp:120, drops:[{item:'stone',      rarity:'common',   pixel:'#888',   weight:40},{item:'mithril_ore',rarity:'common',   pixel:'#9bd1e8',weight:45},{item:'quartz',     rarity:'uncommon', pixel:'#7ba8c4',weight:14.5},{item:'mithril_ore',rarity:'legendary',pixel:'#cfeaf5',weight:0.5}]},
};
MB.MINE_ENEMIES = [
  { key:'slime', name:'SHADE SLIME', tier:1, hp:50,  xp:18, minLevel:1,  maxLevel:999, shape:'SLIME', drops:[{item:'stone',rarity:'common',pixel:'#aaa',weight:65},{item:'quartz',rarity:'uncommon',pixel:'#888',weight:30},{item:'geode',rarity:'legendary',pixel:'#fff',weight:5}]},
  { key:'golem', name:'STONE GOLEM', tier:2, hp:95,  xp:45, minLevel:10, maxLevel:999, shape:'GOLEM', drops:[{item:'stone',rarity:'common',pixel:'#777',weight:55},{item:'copper_ore',rarity:'uncommon',pixel:'#6bb5ff',weight:38},{item:'mithril_ore',rarity:'legendary',pixel:'#cfeaf5',weight:7}]},
];

// ── ECONOMY CONSTANTS ──────────────────────────────────────────
MB.ECONOMY = {
  auctionListingFee: 0.05,   // 5% of listing price
  craftSwitchCost:   500,    // doubloons to reset craft profession
  // Profession level unlock gates
  miningUnlocks: [
    { level:1,  materials:['copper_ore','tin_ore','stone'] },
    { level:20, materials:['iron_ore','coal'] },
    { level:40, materials:['silver_ore','quartz'] },
    { level:60, materials:['gold_ore','obsidian'] },
    { level:80, materials:['mithril_ore'] },
    { level:100,materials:['starstone'] },
  ],
  // Drop rate modifiers by level (0–100)
  dropRateLevelBonus: function(rarity, level) {
    const lb = level / 100;
    if (rarity === 'uncommon') return lb * 0.5;
    if (rarity === 'rare')     return lb * 0.7;
    if (rarity === 'legendary')return lb * 0.3;
    return 0;
  },
};

// ── UTILITY ────────────────────────────────────────────────────
// Render a nav bar into any element. Highlights current page.
MB.renderNav = function(containerId, currentPage) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const pages = [
    { key:'hub',       label:'Hub'       },
    { key:'games',     label:'Games'     },
    { key:'inventory', label:'Inventory' },
    { key:'auction',   label:'Auction'   },
    { key:'mail',      label:'Mail'      },
    { key:'myths',     label:'✦ Myths',  special:'myth' },
  ];
  el.innerHTML = pages.map(p => {
    const on = p.key === currentPage ? ' on' : '';
    const sp = p.special ? ` ${p.special}` : '';
    const wip = (!MB.PAGES[p.key] || p.key==='auction'||p.key==='mail'||p.key==='myths') ? ' wip' : '';
    return `<button class="nb${on}${sp}${wip}" onclick="MB.nav('${p.key}')">${p.label}${wip?' 🚧':''}</button>`;
  }).join('');
};

// Render player bar into any element
MB.renderPlayerBar = function(containerId, opts) {
  opts = opts || {};
  const el = document.getElementById(containerId);
  if (!el) return;
  const p = MB.PLAYER;
  const prof = opts.profession;
  const xpData = prof ? p.professions[prof] : null;
  el.innerHTML = `
    <div class="pav">${p.em}</div>
    <div>
      <div class="pname">${p.name}</div>
      <div class="pinfo">Lv.${p.level} ${p.role}${p.myth ? ' · '+p.myth+' Mythbound' : ''}</div>
    </div>
    ${xpData ? `<div class="xp-wrap">
      <div class="xp-lbl">${prof.toUpperCase()} Lv.${xpData.level}</div>
      <div class="xp-bg"><div class="xp-f" style="width:${Math.round(xpData.xp/xpData.xpMax*100)}%"></div></div>
      <div class="xp-n">${xpData.xp}/${xpData.xpMax} XP</div>
    </div>` : ''}
    <div class="coins" style="margin-left:auto;">${p.coins.toLocaleString()} 🪙</div>
    ${opts.extra || ''}
  `;
};

console.log('[MB] mythbound_shared.js loaded');
