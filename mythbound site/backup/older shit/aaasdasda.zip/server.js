// ============================================================
//  MYTHBOUND — Local Dev Server
//  1. Put this file in your mythbound/ folder
//  2. Run: node server.js
//  3. Open: http://localhost:3000
// ============================================================

const http = require('http');
const fs   = require('fs');
const path = require('path');
const ROOT = __dirname;

const MIME = {
  '.html': 'text/html',
  '.js':   'text/javascript',
  '.css':  'text/css',
  '.json': 'application/json',
  '.png':  'image/png',
  '.jpg':  'image/jpeg',
  '.gif':  'image/gif',
  '.svg':  'image/svg+xml',
  '.ico':  'image/x-icon',
};

// ── LIVE RELOAD ───────────────────────────────────────────────
const reloadClients = [];
let reloadTimer = null;
function scheduleReload(filename) {
  clearTimeout(reloadTimer);
  reloadTimer = setTimeout(() => {
    console.log('  ↻ changed:', filename, '— reloading browser');
    reloadClients.forEach(res => { try { res.write('data: reload\n\n'); } catch(e) {} });
    reloadClients.length = 0;
  }, 80);
}
function watchDir(dir) {
  try {
    fs.readdirSync(dir).forEach(f => {
      const full = path.join(dir, f);
      try {
        const stat = fs.statSync(full);
        if (stat.isDirectory() && f !== 'node_modules' && !f.startsWith('.')) watchDir(full);
        else if (stat.isFile()) fs.watch(full, () => scheduleReload(f));
      } catch(e) {}
    });
  } catch(e) {}
}
watchDir(ROOT);

const RELOAD_SNIPPET = `
<script>
(function(){
  var es = new EventSource('/__reload');
  es.onmessage = function(e){ if(e.data==='reload') location.reload(); };
  es.onerror   = function(){ setTimeout(function(){ location.reload(); }, 1500); };
})();
</script>`;

// ── CHAT SYNC ─────────────────────────────────────────────────
// In-memory chat log per channel — cleared on server restart.
// In production: replace with Supabase Realtime subscriptions.
// Clients connect to /__chat/stream, POST to /__chat/send.
// Server fans messages out to all connected SSE clients instantly.

const MAX_HISTORY = 200;
// chatHistory[channel] = array of message objects
const chatHistory = {};
const chatClients = []; // { res, channel }

function getHistory(channel) {
  if (!chatHistory[channel]) chatHistory[channel] = [];
  return chatHistory[channel];
}

function broadcastChat(msg) {
  const json = 'data: ' + JSON.stringify(msg) + '\n\n';
  chatClients.forEach(client => {
    if (client.channel === msg.channel || client.channel === 'all') {
      try { client.res.write(json); } catch(e) {}
    }
  });
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => { body += chunk; if (body.length > 64000) reject(new Error('Too large')); });
    req.on('end', () => { try { resolve(JSON.parse(body)); } catch(e) { reject(e); } });
    req.on('error', reject);
  });
}

// ── SERVER ────────────────────────────────────────────────────
const server = http.createServer(async (req, res) => {
  const url = req.url.split('?')[0];

  // CORS for same-origin dev
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  // ── Live reload SSE ──
  if (url === '/__reload') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });
    res.write(':\n\n');
    reloadClients.push(res);
    req.on('close', () => { const i = reloadClients.indexOf(res); if (i !== -1) reloadClients.splice(i, 1); });
    return;
  }

  // ── Chat stream (SSE) — GET /__chat/stream?channel=global ──
  if (url.startsWith('/__chat/stream')) {
    const channel = new URL(req.url, 'http://localhost').searchParams.get('channel') || 'global';
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });
    res.write(':\n\n');
    // Send history on connect
    const hist = getHistory(channel);
    if (hist.length) res.write('data: ' + JSON.stringify({ type: 'history', messages: hist }) + '\n\n');
    const client = { res, channel };
    chatClients.push(client);
    req.on('close', () => { const i = chatClients.indexOf(client); if (i !== -1) chatClients.splice(i, 1); });
    // Keep-alive ping every 20s
    const ping = setInterval(() => { try { res.write(':\n\n'); } catch(e) { clearInterval(ping); } }, 20000);
    req.on('close', () => clearInterval(ping));
    return;
  }

  // ── Chat send — POST /__chat/send ──
  if (url === '/__chat/send' && req.method === 'POST') {
    try {
      const msg = await parseBody(req);
      if (!msg || !msg.channel || !msg.text || !msg.name) {
        res.writeHead(400); res.end('Bad request'); return;
      }
      // Sanitise
      msg.text    = String(msg.text).slice(0, 500);
      msg.name    = String(msg.name).slice(0, 32);
      msg.em      = String(msg.em  || '?').slice(0, 8);
      msg.ts      = Date.now();
      msg.id      = msg.id || msg.name.toLowerCase();
      msg.type    = msg.type || 'chat';
      // Store
      const hist = getHistory(msg.channel);
      hist.push(msg);
      if (hist.length > MAX_HISTORY) hist.splice(0, hist.length - MAX_HISTORY);
      // Broadcast
      broadcastChat(msg);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true, ts: msg.ts }));
    } catch(e) {
      res.writeHead(500); res.end('Error: ' + e.message);
    }
    return;
  }

  // ── Chat history — GET /__chat/history?channel=global ──
  if (url.startsWith('/__chat/history')) {
    const channel = new URL(req.url, 'http://localhost').searchParams.get('channel') || 'global';
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(getHistory(channel)));
    return;
  }


  // ── Game data — GET /__data ──
  if (url === '/__data' && req.method !== 'POST') {
    try {
      const data = fs.readFileSync(path.join(ROOT, 'mythbound_data.json'), 'utf8');
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(data);
    } catch(e) {
      res.writeHead(404); res.end('mythbound_data.json not found');
    }
    return;
  }

  // ── Game data save — POST /__data ──
  if (url === '/__data' && req.method === 'POST') {
    try {
      const body = await parseBody(req);
      // Safety: validate it has required keys before writing
      if (!body.items || !body.economy) {
        res.writeHead(400); res.end('Invalid data: missing items or economy'); return;
      }
      // Write atomically: temp file then rename
      const dest = path.join(ROOT, 'mythbound_data.json');
      const tmp  = dest + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(body, null, 2), 'utf8');
      fs.renameSync(tmp, dest);
      console.log('  ✓ mythbound_data.json saved (' + JSON.stringify(body).length + ' bytes)');
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true }));
    } catch(e) {
      console.error('  ✗ data save failed:', e.message);
      res.writeHead(500); res.end('Save failed: ' + e.message);
    }
    return;
  }


  // Favicon — suppress 404 noise
  if (url === '/favicon.ico') {
    res.writeHead(204); res.end(); return;
  }

  // ── Static files ──
  let filePath = url === '/' ? path.join(ROOT, 'mythbound_hub.html') : path.join(ROOT, url);
  if (!filePath.startsWith(ROOT)) { res.writeHead(403); res.end('Forbidden'); return; }

  fs.readFile(filePath, (err, data) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); res.end('Not found: ' + url); return; }
    const ext  = path.extname(filePath).toLowerCase();
    const mime = MIME[ext] || 'application/octet-stream';
    if (ext === '.html') {
      const html = data.toString().replace('</body>', RELOAD_SNIPPET + '\n</body>');
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(html);
    } else {
      res.writeHead(200, { 'Content-Type': mime });
      res.end(data);
    }
  });
});

const PORT = 3000;
server.listen(PORT, () => {
  console.log('');
  console.log('  ╔════════════════════════════════════╗');
  console.log('  ║   MYTHBOUND dev server running     ║');
  console.log('  ║   http://localhost:' + PORT + '             ║');
  console.log('  ╚════════════════════════════════════╝');
  console.log('');
  console.log('  Chat sync: ws-free SSE broadcast active');
  console.log('  Watching for file changes...');
  console.log('  Press Ctrl+C to stop.');
  console.log('');
});
